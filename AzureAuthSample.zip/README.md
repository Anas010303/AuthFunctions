# AzureAuthSample

This solution contains two projects:

1. **AuthFunctions** - Azure Functions (HTTP-triggered) handling Register, Login, EditProfile using Azure Table Storage and Blob Storage.
2. **MvcFrontend** - ASP.NET Core MVC frontend that calls the Functions endpoints, stores JWT in HttpOnly cookie, and provides pages for Register, Login, Landing, Edit Profile and file upload.

## How to run locally

### Prerequisites
- .NET 6 SDK
- Azure Functions Core Tools (for running Functions locally) - optional if you deploy to Azure
- An Azure Storage account connection string for local testing (tables + blobs)

### Steps

1. Open the solution folder `AzureAuthSample` in Visual Studio.
2. Configure local settings:
   - For **AuthFunctions**, edit `AuthFunctions/local.settings.json` and set `AzureTableStorage_ConnectionString`, `AzureBlobStorage_ConnectionString`, `JwtSecret`.
   - For **MvcFrontend**, edit `MvcFrontend/appsettings.json` and set `FunctionsApiBaseUrl` (e.g., http://localhost:7071/api when running Functions locally) and `AzureBlobStorage_ConnectionString` if uploading directly from MVC.
3. Run AuthFunctions (press F5 in Visual Studio or `func start` in the AuthFunctions folder).
4. Run MvcFrontend (set as Startup project) and open browser.
5. Register, login, edit profile.

This sample is for educational/demo purposes. Do not use secrets in source code in production.

