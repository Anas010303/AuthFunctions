using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System;
using System.Linq;
using AuthFunctions.Services;
using AuthFunctions.Utils;

namespace AuthFunctions.Functions
{
    public class EditProfileFunction
    {
        private readonly TableUserService _userService;
        private readonly string _jwtSecret;
        private readonly string _jwtIssuer;
        private readonly string _jwtAudience;

        public EditProfileFunction()
        {
            var conn = Environment.GetEnvironmentVariable("AzureTableStorage_ConnectionString");
            _userService = new TableUserService(conn);
            _jwtSecret = Environment.GetEnvironmentVariable("JwtSecret");
            _jwtIssuer = Environment.GetEnvironmentVariable("JwtIssuer") ?? "myapp";
            _jwtAudience = Environment.GetEnvironmentVariable("JwtAudience") ?? "myapp_users";
        }

        [Function("EditProfile")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "auth/edit")] HttpRequestData req)
        {
            var response = req.CreateResponse();

            if (!req.Headers.TryGetValues("Authorization", out var vals))
            {
                response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                return response;
            }
            var auth = vals.FirstOrDefault();
            if (string.IsNullOrEmpty(auth) || !auth.StartsWith("Bearer "))
            {
                response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                return response;
            }
            var token = auth.Substring("Bearer ".Length).Trim();

            try
            {
                var principal = JwtHelper.ValidateToken(token, _jwtSecret, _jwtIssuer, _jwtAudience);
                var userId = principal.FindFirst("uid")?.Value;
                if (string.IsNullOrEmpty(userId))
                {
                    response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                    return response;
                }

                var existing = await _userService.GetByUserIdAsync(userId);
                if (existing == null)
                {
                    response.StatusCode = System.Net.HttpStatusCode.NotFound;
                    return response;
                }

                var body = await new StreamReader(req.Body).ReadToEndAsync();
                var dto = JsonSerializer.Deserialize<EditDto>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (!string.IsNullOrWhiteSpace(dto.DisplayName)) existing.DisplayName = dto.DisplayName;
                if (!string.IsNullOrWhiteSpace(dto.Username)) existing.Username = dto.Username;
                if (!string.IsNullOrWhiteSpace(dto.Email)) existing.Email = dto.Email.ToLowerInvariant();
                if (!string.IsNullOrWhiteSpace(dto.BlobUrl)) existing.BlobUrl = dto.BlobUrl;
                existing.UpdatedAt = DateTime.UtcNow;

                await _userService.UpdateAsync(existing);
                response.StatusCode = System.Net.HttpStatusCode.OK;
                await response.WriteStringAsync(JsonSerializer.Serialize(new { message = "Updated", user = existing }));
                return response;
            }
            catch (Exception)
            {
                response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                return response;
            }
        }

        public class EditDto
        {
            public string DisplayName { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string BlobUrl { get; set; }
        }
    }
}
