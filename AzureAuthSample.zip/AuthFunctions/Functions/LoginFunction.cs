using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System;
using AuthFunctions.Services;
using AuthFunctions.Utils;

namespace AuthFunctions.Functions
{
    public class LoginFunction
    {
        private readonly TableUserService _userService;
        private readonly string _jwtSecret;
        private readonly string _jwtIssuer;
        private readonly string _jwtAudience;

        public LoginFunction()
        {
            var conn = Environment.GetEnvironmentVariable("AzureTableStorage_ConnectionString");
            _userService = new TableUserService(conn);
            _jwtSecret = Environment.GetEnvironmentVariable("JwtSecret");
            _jwtIssuer = Environment.GetEnvironmentVariable("JwtIssuer") ?? "myapp";
            _jwtAudience = Environment.GetEnvironmentVariable("JwtAudience") ?? "myapp_users";
        }

        [Function("Login")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "auth/login")] HttpRequestData req)
        {
            var body = await new StreamReader(req.Body).ReadToEndAsync();
            var dto = JsonSerializer.Deserialize<LoginDto>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            var response = req.CreateResponse();
            if (dto == null || string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Password))
            {
                response.StatusCode = System.Net.HttpStatusCode.BadRequest;
                await response.WriteStringAsync("Email and password required");
                return response;
            }

            var user = await _userService.GetByEmailAsync(dto.Email.ToLowerInvariant());
            if (user == null)
            {
                response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                return response;
            }

            var verified = PasswordHasher.Verify(dto.Password, user.PasswordHash, user.PasswordSalt);
            if (!verified)
            {
                response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                return response;
            }

            var token = JwtHelper.GenerateToken(user.RowKey, user.Email, _jwtSecret, _jwtIssuer, _jwtAudience, expireMinutes: 60 * 24);
            response.StatusCode = System.Net.HttpStatusCode.OK;
            await response.WriteStringAsync(JsonSerializer.Serialize(new
            {
                token,
                user = new {
                    id = user.RowKey,
                    email = user.Email,
                    username = user.Username,
                    displayName = user.DisplayName,
                    blobUrl = user.BlobUrl
                }
            }));
            return response;
        }

        public class LoginDto { public string Email { get; set; } public string Password { get; set; } }
    }
}
