using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using AuthFunctions.Services;
using AuthFunctions.Models;
using AuthFunctions.Utils;

namespace AuthFunctions.Functions
{
    public class RegisterFunction
    {
        private readonly TableUserService _userService;

        public RegisterFunction()
        {
            var conn = Environment.GetEnvironmentVariable("AzureTableStorage_ConnectionString");
            _userService = new TableUserService(conn);
        }

        [Function("Register")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "auth/register")] HttpRequestData req)
        {
            var body = await new StreamReader(req.Body).ReadToEndAsync();
            var dto = JsonSerializer.Deserialize<RegisterDto>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            var response = req.CreateResponse();
            if (dto == null || string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Password))
            {
                response.StatusCode = System.Net.HttpStatusCode.BadRequest;
                await response.WriteStringAsync("Email and password required");
                return response;
            }

            var existing = await _userService.GetByEmailAsync(dto.Email.ToLowerInvariant());
            if (existing != null)
            {
                response.StatusCode = System.Net.HttpStatusCode.Conflict;
                await response.WriteStringAsync("User already exists");
                return response;
            }

            var (hash, salt) = PasswordHasher.HashPassword(dto.Password);
            var user = new UserEntity
            {
                RowKey = Guid.NewGuid().ToString(),
                Username = dto.Username ?? dto.Email,
                Email = dto.Email.ToLowerInvariant(),
                PasswordHash = hash,
                PasswordSalt = salt,
                DisplayName = dto.DisplayName ?? dto.Username ?? dto.Email,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            await _userService.InsertAsync(user);
            response.StatusCode = System.Net.HttpStatusCode.OK;
            await response.WriteStringAsync(JsonSerializer.Serialize(new { message = "Registered" }));
            return response;
        }

        public class RegisterDto
        {
            public string Email { get; set; }
            public string Password { get; set; }
            public string Username { get; set; }
            public string DisplayName { get; set; }
        }
    }
}
