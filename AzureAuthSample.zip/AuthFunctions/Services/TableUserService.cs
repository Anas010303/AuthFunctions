using Azure;
using Azure.Data.Tables;
using System;
using System.Linq;
using System.Threading.Tasks;
using AuthFunctions.Models;

namespace AuthFunctions.Services
{
    public class TableUserService
    {
        private readonly TableClient _tableClient;

        public TableUserService(string connectionString, string tableName = "Users")
        {
            _tableClient = new TableClient(connectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        public async Task<UserEntity> GetByEmailAsync(string email)
        {
            var q = _tableClient.QueryAsync<UserEntity>(e => e.Email == email);
            await foreach (var e in q)
            {
                return e;
            }
            return null;
        }

        public async Task<UserEntity> GetByUserIdAsync(string userId)
        {
            try
            {
                var response = await _tableClient.GetEntityAsync<UserEntity>("USER", userId);
                return response.Value;
            }
            catch (RequestFailedException) { return null; }
        }

        public async Task InsertAsync(UserEntity user)
        {
            await _tableClient.AddEntityAsync(user);
        }

        public async Task UpdateAsync(UserEntity user)
        {
            await _tableClient.UpsertEntityAsync(user, TableUpdateMode.Replace);
        }
    }
}
