using Azure;
using Azure.Data.Tables;
using System;

namespace AuthFunctions.Models
{
    public class UserEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "USER";
        public string RowKey { get; set; } // UserId (GUID)
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }

        // Custom fields
        public string Username { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string PasswordSalt { get; set; }
        public string DisplayName { get; set; }
        public string BlobUrl { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
