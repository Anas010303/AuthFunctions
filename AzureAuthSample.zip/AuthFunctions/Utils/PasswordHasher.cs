using System;
using System.Security.Cryptography;

namespace AuthFunctions.Utils
{
    public static class PasswordHasher
    {
        public static (string hash, string salt) HashPassword(string password, int saltSize = 16, int iterations = 100_000, int keySize = 32)
        {
            using var rng = RandomNumberGenerator.Create();
            var saltBytes = new byte[saltSize];
            rng.GetBytes(saltBytes);
            var salt = Convert.ToBase64String(saltBytes);
            var hashBytes = Rfc2898DeriveBytes.Pbkdf2(
                password,
                saltBytes,
                iterations,
                HashAlgorithmName.SHA256,
                keySize
            );
            return (Convert.ToBase64String(hashBytes), salt);
        }

        public static bool Verify(string password, string storedHash, string storedSalt, int iterations = 100_000, int keySize = 32)
        {
            var saltBytes = Convert.FromBase64String(storedSalt);
            var hashBytes = Rfc2898DeriveBytes.Pbkdf2(password, saltBytes, iterations, HashAlgorithmName.SHA256, keySize);
            var computed = Convert.ToBase64String(hashBytes);
            // constant time compare
            var a = Convert.FromBase64String(computed);
            var b = Convert.FromBase64String(storedHash);
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
