using System;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace MvcFrontend.Utils
{
    public static class JwtHelper
    {
        public static System.Security.Claims.ClaimsPrincipal ValidateToken(string token, string secret, string issuer, string audience)
        {
            var handler = new JwtSecurityTokenHandler();
            var parameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = issuer,
                ValidAudience = audience,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
                ClockSkew = TimeSpan.FromMinutes(2)
            };
            return handler.ValidateToken(token, parameters, out var validatedToken);
        }
    }
}
