using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using MvcFrontend.Utils;
using System;

namespace MvcFrontend.Middleware
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly string _secret;
        private readonly string _issuer;
        private readonly string _audience;

        public JwtMiddleware(RequestDelegate next, IConfiguration config)
        {
            _next = next;
            _secret = config["JwtSecret"];
            _issuer = config["JwtIssuer"];
            _audience = config["JwtAudience"];
        }

        public async Task Invoke(HttpContext context)
        {
            var token = context.Request.Cookies["AuthToken"];
            if (!string.IsNullOrEmpty(token))
            {
                try
                {
                    var principal = JwtHelper.ValidateToken(token, _secret, _issuer, _audience);
                    context.User = principal;
                }
                catch
                {
                    // invalid token -> ignore
                }
            }
            await _next(context);
        }
    }
}
