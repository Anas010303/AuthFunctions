using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text.Json;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System;

namespace MvcFrontend.Controllers
{
    public class ProfileController : Controller
    {
        private readonly IHttpClientFactory _http;
        private readonly IConfiguration _config;

        public ProfileController(IHttpClientFactory http, IConfiguration config)
        {
            _http = http; _config = config;
        }

        public IActionResult Edit() => View();

        [HttpPost]
        public async Task<IActionResult> Edit(IFormFile file, EditModel model)
        {
            string blobUrl = null;
            if (file != null && file.Length > 0)
            {
                var conn = _config["AzureBlobStorage_ConnectionString"];
                var containerName = "user-docs";
                var blobService = new BlobServiceClient(conn);
                var container = blobService.GetBlobContainerClient(containerName);
                await container.CreateIfNotExistsAsync();

                var blobName = $"{Guid.NewGuid()}-{file.FileName}";
                var blob = container.GetBlobClient(blobName);
                using var stream = file.OpenReadStream();
                await blob.UploadAsync(stream);
                blobUrl = blob.Uri.ToString();
            }

            var token = Request.Cookies["AuthToken"];
            var dto = new { DisplayName = model.DisplayName, Username = model.Username, Email = model.Email, BlobUrl = blobUrl };
            var client = _http.CreateClient();
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var res = await client.PutAsync($"{_config["FunctionsApiBaseUrl"]}/auth/edit",
                new StringContent(JsonSerializer.Serialize(dto), Encoding.UTF8, "application/json"));

            if (!res.IsSuccessStatusCode)
            {
                ModelState.AddModelError("", "Could not update profile");
                return View(model);
            }

            return RedirectToAction("Index", "Landing");
        }
    }

    public class EditModel { public string DisplayName { get; set; } public string Username { get; set; } public string Email { get; set; } }
}
