using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace MvcFrontend.Controllers
{
    public class AccountController : Controller
    {
        private readonly IHttpClientFactory _http;
        private readonly IConfiguration _config;

        public AccountController(IHttpClientFactory http, IConfiguration config)
        {
            _http = http; _config = config;
        }

        private string ApiBase => _config["FunctionsApiBaseUrl"];

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var client = _http.CreateClient();
            var res = await client.PostAsync($"{ApiBase}/auth/register",
                new StringContent(JsonSerializer.Serialize(model), Encoding.UTF8, "application/json"));
            if (res.IsSuccessStatusCode) return RedirectToAction("Login");
            var error = await res.Content.ReadAsStringAsync();
            ModelState.AddModelError("", error);
            return View(model);
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var client = _http.CreateClient();
            var res = await client.PostAsync($"{ApiBase}/auth/login",
                new StringContent(JsonSerializer.Serialize(model), Encoding.UTF8, "application/json"));
            if (!res.IsSuccessStatusCode)
            {
                ModelState.AddModelError("", "Invalid login");
                return View(model);
            }

            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var token = doc.RootElement.GetProperty("token").GetString();

            Response.Cookies.Append("AuthToken", token, new CookieOptions { HttpOnly = true, Secure = false, SameSite = SameSiteMode.Strict });

            return RedirectToAction("Index", "Landing");
        }

        [HttpPost]
        public IActionResult Logout()
        {
            Response.Cookies.Delete("AuthToken");
            return RedirectToAction("Login");
        }
    }

    public class RegisterModel { public string Email { get; set; } public string Password { get; set; } public string Username { get; set; } public string DisplayName { get; set; } }
    public class LoginModel { public string Email { get; set; } public string Password { get; set; } }
}
