using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace MvcFrontend.Controllers
{
    public class LandingController : Controller
    {
        public IActionResult Index()
        {
            if (!User.Identity.IsAuthenticated) return RedirectToAction("Login", "Account");
            var email = User.Claims.FirstOrDefault(c => c.Type == "email" || c.Type == System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Email)?.Value;
            var uid = User.Claims.FirstOrDefault(c => c.Type == "uid")?.Value;
            var model = new LandingViewModel { Email = email, UserId = uid, DisplayName = User.Identity.Name ?? email };
            return View(model);
        }
    }

    public class LandingViewModel { public string UserId { get; set; } public string Email { get; set; } public string DisplayName { get; set; } }
}
